#include "main.h"


void EXTI9_5_IRQHandler()
{
		if ((EXTI->PR & EXTI_PR_PR9)!=0)
		{
			delay(100000000); //ot drebezga;
			GPIOD->ODR ^= GPIO_ODR_ODR4;
			EXTI->PR |= EXTI_PR_PR9;
		}
}

void initBtn()
{
	RCC->APB2ENR |= RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN;
	
	GPIOD->CRH &= ~(GPIO_CRH_CNF9 | GPIO_CRH_MODE9);
	GPIOD->CRH |= GPIO_CRH_CNF9_1;
	GPIOB->BSRR = GPIO_BSRR_BR9;
	
	AFIO->EXTICR[2] |= AFIO_EXTICR3_EXTI9_PB;
	
	EXTI->IMR |= EXTI_IMR_MR9;
	EXTI->FTSR |= EXTI_FTSR_TR9;
	
	NVIC_EnableIRQ(EXTI9_5_IRQn);
	NVIC_SetPriority(EXTI9_5_IRQn,0);
		
	
}

int main(void)
{
	//PORTD: 3,4,7,13
	
	RCC->APB2ENR|=RCC_APB2ENR_IOPDEN;
	GPIOD->CRL &= ~(GPIO_CRL_CNF3 | GPIO_CRL_MODE3);
	GPIOD->CRL &= ~(GPIO_CRL_CNF4 | GPIO_CRL_MODE4);
	GPIOD->CRL &= ~(GPIO_CRL_CNF7 | GPIO_CRL_MODE7);
	GPIOD->CRH &= ~(GPIO_CRH_CNF13 | GPIO_CRH_MODE13);
	
	GPIOD->CRL |= (GPIO_CRL_MODE3_1);
	GPIOD->CRL |= (GPIO_CRL_MODE4_1);
	GPIOD->CRL |= (GPIO_CRL_MODE7_1);
	GPIOD->CRH |= (GPIO_CRH_MODE13_1);
	
	initBtn();
	
	while(1)
	{
		LED1_ON();
		delay(DELAY_VAL);
		LED1_OFF();
		LED2_ON();
		delay(DELAY_VAL);
		LED2_OFF();
//		
		LED3_ON();
		delay(DELAY_VAL);
		LED3_OFF();
		
		LED4_ON();
		delay(DELAY_VAL);
		LED4_OFF();
		
		

		
	}
}

void delay(uint32_t t)
{
	for( uint32_t i=0; i<=t; i++);
}